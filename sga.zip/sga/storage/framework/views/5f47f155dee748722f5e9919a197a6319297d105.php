<?php $__env->startSection('title', 'Create Av'); ?>

<?php $__env->startSection('file_css'); ?>
    <link href="<?php echo e(mix('css/createAv_style.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-md-9 conteudo" >

        <div class="row">
            <div class="col-10">
                <h2>Marcar Avaliações</h2>

            </div>
            <div class="col">
                <a id="question" data-toggle="tooltip" data-html="true" data-placement="right" title="Insira os dados necessários abaixo e clique no botão <b>Marcar</b>">
                    <i class="fa fa-question-circle fa-lg text-black-50" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    <br>


    <form method="POST" class="form-inline" action="<?php echo e(route('admin.createAv.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body" id="filtro">

                <div class="row">

                    <div class="col-3">

                        <div class="form-group">
                            <select class="form-control" id="cursos" name="curso" >
                                <option selected disabled class="opt">Curso</option>
                                <?php
                                    $firstname = explode(' ', $name);
                                    $tipo_curso = "";
                                    $nome = "";
                                ?>

                                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $firstname2 = explode(' ', $curso->nome_completo); ?>
                                    <?php if($firstname2[0] === $firstname[0]): ?>

                                        <?php if($tipo_curso === $curso->descricao_tipo and $nome !== $curso->nome_cursos): ?>
                                            <?php $nome = $curso->nome_cursos; ?>
                                            <option id="curso" value = '<?php echo e($curso->id_curso); ?>'><?php echo e($curso->nome_cursos); ?></option>
                                        <?php endif; ?>
                                        <?php if($tipo_curso !== $curso->descricao_tipo): ?>
                                            <?php $tipo_curso = $curso->descricao_tipo; ?>
                                            <option disabled><?php echo e($curso->descricao_tipo); ?></option>
                                            <?php if($nome !== $curso->nome_cursos): ?>
                                                <?php $nome = $curso->nome_cursos; ?>
                                                <option id="curso" value = '<?php echo e($curso->id_curso); ?>'><?php echo e($curso->nome_cursos); ?></option>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <select class="form-control" id="uc" name="uc">
                                <option selected disabled>Unidade Curricular</option>
                            </select>

                        </div>

                        <a href="#fil" id="filtable" data-toggle="collapse" >Filtrar Tabela <i class="fa fa-arrow-circle-down" aria-hidden="true"></i></a>
                        <a href="#" id="verTable" onclick="loadtable()">Ver Todas <i class="fa fa-refresh" aria-hidden="true"></i></a>


                    </div>

                    <div class="col-3">
                        <div class="form-group">
                            <select class="form-control" id="epoca" name="epoca">
                                <option selected disabled>Época</option>
                                <!-- Desenvolver com BackEnd -->
                                <?php $__currentLoopData = $epocas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $epoca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($epoca->id_epoca); ?>"> <?php echo e($epoca->descricao_ep); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Insira a sala" id="sala" name="sala">
                        </div>

                    </div>


                    <div class="col-3">
                        <div class="form-group" id="ip_hora">
                            <label for="hora"><b>Hora da Avaliação:</b></label> <br>
                            <input type="time" class="form-control" placeholder="Insira uma Hora" id="hora" name="hora">
                        </div>
                    </div>


                    <div class="col-3">
                        <div class="form-group" id="ip_data">
                            <label for="data"><b>Data da Avaliação:</b></label> <br>
                            <input type="date" class="form-control" placeholder="Insira a data" id="data" name="data">
                        </div>
                    </div>

                </div>
            </div>
        </div>


        <div id="fil" class="collapse">
            <div class="card" id="filtroTable">
                <div class="card-body">
                     <div class="row">

                        <div class="col-8">

                            <select class="form-control" id="AnoLetivo" name="anoletivo" >
                                <option selected disabled class="opt">Ano Letivo</option>
                                <?php $__currentLoopData = $anosLetivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ano): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option class="opt" value="<?php echo e($ano->id_anoLetivo); ?>"> <?php echo e($ano->descricao_al); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                        </div>


                        <div class="col-4">
                            <button type="button" class="btn btn-secondary" id="filtrar">Filtrar</button>
                        </div>

                    </div>


                </div>
            </div>
        </div>


        <table class="table table-striped table-responsive" id="aval">
            <thead class="thead">
            <tr>
                <th scope="col" class="th-sm">Ano Letivo</th>
                <th scope="col" class="th-sm">Ano</th>
                <th scope="col" class="th-sm">Período</th>
                <th scope="col" class="th-sm">Unidade Curricular</th>
                <th scope="col" class="th-sm">Data de Avaliação</th>
                <th scope="col" class="th-sm">Hora</th>
                <th scope="col" class="th-sm">Sala</th>
                <th scope="col" class="th-sm">Época</th>
            </tr>
            </thead>
            <tbody id="avaliacao">
                <tr>
                    <td colspan="8" class="td_h">Insira primeiro o curso </td>
                </tr>
            </tbody>
        </table>

        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success" id="success">
                <?php echo \Session::get('success'); ?>

            </div>
        <?php endif; ?>

        <button type="submit" class="btn" id="marcar">Marcar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('js/createAv.js')); ?>"></script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sga\resources\views/admin/avaliacao/createAv.blade.php ENDPATH**/ ?>