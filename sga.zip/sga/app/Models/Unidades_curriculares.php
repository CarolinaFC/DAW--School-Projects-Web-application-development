<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Unidades_curriculares extends Model
{
    use HasFactory;
    protected $table = "Unidades_curriculares";
}
